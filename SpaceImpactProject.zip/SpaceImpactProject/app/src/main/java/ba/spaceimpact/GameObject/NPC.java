package ba.spaceimpact.GameObject;

/**
 * Created by busraarabaci on 02/11/2017.
 */

public interface NPC extends SpaceShip {

}
