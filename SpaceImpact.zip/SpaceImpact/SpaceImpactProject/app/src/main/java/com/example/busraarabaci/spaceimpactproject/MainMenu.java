package com.example.busraarabaci.spaceimpactproject;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.animation.AlphaAnimation;
import android.widget.Toast;

public class MainMenu extends Activity {

    private AlphaAnimation buttonClick = new AlphaAnimation(1F, 0.8F);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);

        setContentView(R.layout.activity_main_menu);
    }

    public void startGame(View v){
        v.startAnimation(buttonClick);
        //Toast.makeText(getApplicationContext(), "Button",Toast.LENGTH_LONG).show();

        Intent intent = new Intent(this, SpaceshipMove.class);
        startActivity(intent);

    }
}
